import{M as e,Wt as t,yr as n}from"./three.core-BPEP_1Y2.js";import{d as r,f as i,g as a,h as o,l as s,m as c,p as l,r as u,s as d,u as f}from"./index-RrEl-eJq.js";var p=`# Open in Blender's Scripting workspace and click Run Script.
import bpy
import json
from math import radians, atan, tan
from mathutils import Vector
from pathlib import Path

data = json.loads(VD3D_PAYLOAD)

def rgba(hex_color, alpha=1):
    def linear(component):
        return component / 12.92 if component <= 0.04045 else ((component + 0.055) / 1.055) ** 2.4
    return (*[linear(int(hex_color[i:i + 2], 16) / 255) for i in (1, 3, 5)], alpha)

scene = bpy.data.scenes.new(data["name"])
bpy.context.window.scene = scene
scene.render.engine = 'CYCLES'
scene.cycles.samples = 32
scene.cycles.use_denoising = True
scene.render.fps = data["fps"]
scene.frame_end = data["count"]
aspect = data["aspect"]
scene.render.resolution_x = round(1920 * min(1, aspect))
scene.render.resolution_y = round(1920 / max(1, aspect))
scene.world = bpy.data.worlds.new("VD3D Studio")
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs["Strength"].default_value = 0.4 * data["lights"]["fill"]

def add_object(name, block):
    obj = bpy.data.objects.new(name, block)
    scene.collection.objects.link(obj)
    return obj

for layer in data["layers"]:
    mesh = bpy.data.meshes.new(layer["name"])
    mesh.from_pydata(layer["vertices"], [], layer["faces"], shade_flat=False)
    mesh.normals_split_custom_set(layer["normals"])
    mesh.update()
    obj = add_object(layer["name"], mesh)
    obj.rotation_mode = 'QUATERNION'
    material = bpy.data.materials.new(layer["name"])
    material.use_nodes = True
    mesh.materials.append(material)
    shader = material.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Metallic"].default_value = layer["metalness"]
    shader.inputs["Coat Weight"].default_value = layer["coat"]
    shader.inputs["Transmission Weight"].default_value = layer["transmission"]
    shader.inputs["IOR"].default_value = layer["ior"]
    shader.inputs["Specular IOR Level"].default_value = layer["specular"] * 0.5
    previous = None
    for frame, pose in enumerate(layer["frames"], 1):
        obj.location = pose["position"]
        obj.rotation_quaternion = pose["rotation"]
        if previous and previous.dot(obj.rotation_quaternion) < 0:
            obj.rotation_quaternion.negate()
        previous = obj.rotation_quaternion.copy()
        obj.scale = pose["scale"]
        if len(layer["frames"]) > 1:
            for prop in ("location", "rotation_quaternion", "scale"):
                obj.keyframe_insert(data_path=prop, frame=frame)
        values = {"Base Color": rgba(pose["color"]), "Alpha": pose["opacity"],
                  "Roughness": pose["roughness"], "Emission Color": rgba(pose["emissive"]),
                  "Emission Strength": 1}
        for name, value in values.items():
            socket = shader.inputs[name]
            socket.default_value = value
            if len(layer["frames"]) > 1:
                socket.keyframe_insert(data_path="default_value", frame=frame)

camera = bpy.data.cameras.new("VD3D Camera")
scene.camera = add_object(camera.name, camera)
scene.camera.rotation_mode = 'QUATERNION'
camera.sensor_fit = 'HORIZONTAL'
previous = None
for frame, pose in enumerate(data["cameras"], 1):
    scene.camera.location = pose["position"]
    scene.camera.rotation_quaternion = (Vector(pose["target"]) - scene.camera.location).to_track_quat('-Z', 'Y')
    if previous and previous.dot(scene.camera.rotation_quaternion) < 0:
        scene.camera.rotation_quaternion.negate()
    previous = scene.camera.rotation_quaternion.copy()
    camera.type = 'ORTHO' if pose["projection"] == 'orthographic' else 'PERSP'
    fov = 35 if aspect >= 1 else min(95, 35 / aspect)
    camera.angle = 2 * atan(tan(radians(fov) / 2) * aspect / pose["zoom"])
    camera.ortho_scale = 5.7 * max(1, aspect) / pose["zoom"]
    if len(data["cameras"]) > 1:
        for prop in ("location", "rotation_quaternion"):
            scene.camera.keyframe_insert(data_path=prop, frame=frame)
        camera.keyframe_insert(data_path="lens", frame=frame)
        camera.keyframe_insert(data_path="ortho_scale", frame=frame)

for name, direction, power, size in (
    ("Key", data["key"], 800 * data["lights"]["strength"], 4),
    ("Fill", [-4, -4, 2], 350 * data["lights"]["fill"], 5),
    ("Rim", [1, 5, 3], 550, 3),
):
    light = bpy.data.lights.new(name, 'AREA')
    light.energy = power
    light.shape = 'DISK'
    light.size = size
    obj = add_object(name, light)
    obj.location = Vector(direction).normalized() * 6
    obj.rotation_euler = (-obj.location).to_track_quat('-Z', 'Y').to_euler()

scene.frame_set(1)
source = Path(bpy.path.abspath(globals().get("__file__", "")))
settings = data.get("render")
if settings:
    scene.cycles.device = 'CPU'
    scene.cycles.samples = settings["samples"]
    scene.render.resolution_x = settings["width"]
    scene.render.resolution_y = settings["height"]
    scene.render.resolution_percentage = 100
    format = settings["format"]
    transparent = settings["transparent"] and format != 'mp4'
    scene.render.film_transparent = transparent
    if format == 'mp4':
        scene.render.image_settings.file_format = 'FFMPEG'
        scene.render.ffmpeg.format = 'MPEG4'
        scene.render.ffmpeg.codec = 'H264'
        scene.render.ffmpeg.constant_rate_factor = 'HIGH'
    else:
        scene.render.image_settings.file_format = 'PNG'
        scene.render.image_settings.color_mode = 'RGBA' if transparent else 'RGB'
    if not transparent:
        nodes = scene.world.node_tree.nodes
        links = scene.world.node_tree.links
        backdrop = nodes.new('ShaderNodeBackground')
        backdrop.inputs["Color"].default_value = rgba(settings["color"])
        mix = nodes.new('ShaderNodeMixShader')
        links.new(nodes.new('ShaderNodeLightPath').outputs["Is Camera Ray"], mix.inputs[0])
        links.new(nodes["Background"].outputs[0], mix.inputs[1])
        links.new(backdrop.outputs[0], mix.inputs[2])
        links.new(mix.outputs[0], nodes["World Output"].inputs["Surface"])

def next_output(source, extension):
    destination = source.with_suffix(extension)
    i = 2
    while destination.exists():
        destination = source.with_name(f"{source.stem}-{i}{extension}")
        i += 1
    return destination.resolve()

if settings:
    if not source.is_file():
        raise RuntimeError("Open the downloaded .py from disk in Blender's Text Editor and run it again.")
    if format == 'png':
        scene.render.filepath = str(next_output(source, '.png'))
    elif format == 'mp4':
        scene.render.filepath = str(next_output(source, '.mp4'))
    else:
        folder = next_output(source, '.frames')
        folder.mkdir()
        scene.render.filepath = str(folder / 'frame-')

    try:
        bpy.ops.render.render(animation=format != 'png', write_still=format == 'png')
    except RuntimeError as error:
        if "denois" not in str(error).lower():
            raise
        scene.cycles.use_denoising = False
        bpy.ops.render.render(animation=format != 'png', write_still=format == 'png')
elif source.is_file():
    bpy.ops.wm.save_as_mainfile(filepath=str(next_output(source, '.blend')))
`;function m(m,h,g){let _=m.timeline??s,v=_.duration*(_.loop===`ping-pong`?2:1),y=g&&g.format!==`png`?d(m,{...g,bitrate:0,supersample:!1,motionSamples:1},0):void 0,b=g&&g.format!==`png`?g.fps:_.fps,x=g?y?.frames??1:Math.ceil(v*b),S=(g?.format===`png`?[g.time]:_.tracks.length?Array.from({length:g?x:x+1},(e,t)=>y?.time(t)??r(Math.min(v,t/b),_.duration,_.loop===`ping-pong`?`ping-pong`:`once`)):[0]).map(e=>f(m,e)),C=S[0].layers.filter(e=>a(m,e).visible).map((n,r)=>{let i=u(n),a=i.getAttribute(`normal`),s=i.getAttribute(`position`),c=[],d=[],f=new Map,p=Array.from({length:s.count},(e,t)=>{let n=[s.getX(t),-s.getZ(t),s.getY(t)],r=n.join(`,`);return f.has(r)||(f.set(r,c.length),c.push(n)),f.get(r)}),m=[];for(let e=0;e<(i.index?.count??p.length);e+=3){let t=[0,1,2].map(t=>i.index?.getX(e+t)??e+t),n=t.map(e=>p[e]);if(new Set(n).size===3){d.push(n);for(let e of t)m.push([a.getX(e),-a.getZ(e),a.getY(e)])}}i.dispose();let h=o[n.material];return{name:n.name,vertices:c,faces:d,normals:m,metalness:n.metalness??h.metalness,coat:n.clearcoat??h.clearcoat,transmission:l(n.material)?n.transmission??1:0,ior:n.ior??1.5,specular:n.specularIntensity??(l(n.material)?.5:1),frames:S.map(i=>{let a=i.layers[r]?.id===n.id?i.layers[r]:i.layers.find(e=>e.id===n.id),o=new t().setFromEuler(new e(...a.rotation));return{position:[a.position[0],-a.position[2],a.position[1]],rotation:[o.w,o.x,-o.z,o.y],scale:[a.scale?.[0]??1,a.scale?.[2]??1,a.scale?.[1]??1],roughness:Math.max(l(n.material)?.06:0,a.roughness??h.roughness),color:a.color,opacity:a.opacity,emissive:a.emissive??`#000000`}})}}),w={...i,...m.lighting},[T,E,D]=c(w),O={render:g,name:m.name,layers:C,fps:b,count:x,aspect:h,lights:w,key:[T,-D,E],cameras:S.map(({camera:e})=>{let t=new n(...e.position),r=new n(...e.target);return{position:[t.x,-t.z,t.y],target:[r.x,-r.z,r.y],projection:e.projection,zoom:e.zoom}})},k=p.replace(`VD3D_PAYLOAD`,()=>JSON.stringify(JSON.stringify(O)).replace(/\u2028/g,`\\u2028`).replace(/\u2029/g,`\\u2029`)),A=URL.createObjectURL(new Blob([k],{type:`text/x-python`})),j=document.createElement(`a`);j.href=A,j.download=(m.name.replace(/[^\p{L}\p{N}_-]+/gu,`_`).slice(0,80)||`VD3D`)+(g?`-CPU-`+g.format+`.py`:`.py`),j.click(),window.setTimeout(()=>URL.revokeObjectURL(A),3e4)}export{m as downloadBlender};