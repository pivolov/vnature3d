import{D as e,Sr as t,b as n,d as r,en as i,g as a,o,s,st as c,t as l,v as u,y as d}from"./extrusion-DNahWIp3.js";var f=`# Open in Blender's Scripting workspace and click Run Script.
import bpy
import json
from math import radians, atan, tan
from mathutils import Vector
from pathlib import Path

data = json.loads(VD3D_PAYLOAD)

def rgba(hex_color, alpha=1):
    def linear(component):
        return component / 12.92 if component <= 0.04045 else ((component + 0.055) / 1.055) ** 2.4
    return (*[linear(int(hex_color[i:i + 2], 16) / 255) for i in (1, 3, 5)], alpha)

scene = bpy.data.scenes.new(data["name"])
bpy.context.window.scene = scene
scene.render.engine = 'CYCLES'
scene.cycles.samples = 32
scene.cycles.use_denoising = True
scene.render.fps = data["fps"]
scene.frame_end = data["count"]
aspect = data["aspect"]
scene.render.resolution_x = round(1920 * min(1, aspect))
scene.render.resolution_y = round(1920 / max(1, aspect))
scene.world = bpy.data.worlds.new("VD3D Studio")
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs["Strength"].default_value = 0.4 * data["lights"]["fill"]

def add_object(name, block):
    obj = bpy.data.objects.new(name, block)
    scene.collection.objects.link(obj)
    return obj

for layer in data["layers"]:
    mesh = bpy.data.meshes.new(layer["name"])
    mesh.from_pydata(layer["vertices"], [], layer["faces"], shade_flat=False)
    mesh.normals_split_custom_set(layer["normals"])
    mesh.update()
    obj = add_object(layer["name"], mesh)
    obj.rotation_mode = 'QUATERNION'
    material = bpy.data.materials.new(layer["name"])
    material.use_nodes = True
    mesh.materials.append(material)
    shader = material.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Metallic"].default_value = layer["metalness"]
    shader.inputs["Coat Weight"].default_value = layer["coat"]
    shader.inputs["Transmission Weight"].default_value = float(layer["glass"])
    previous = None
    for frame, pose in enumerate(layer["frames"], 1):
        obj.location = pose["position"]
        obj.rotation_quaternion = pose["rotation"]
        if previous and previous.dot(obj.rotation_quaternion) < 0:
            obj.rotation_quaternion.negate()
        previous = obj.rotation_quaternion.copy()
        obj.scale = pose["scale"]
        if len(layer["frames"]) > 1:
            for prop in ("location", "rotation_quaternion", "scale"):
                obj.keyframe_insert(data_path=prop, frame=frame)
        values = {"Base Color": rgba(pose["color"]), "Alpha": pose["opacity"],
                  "Roughness": pose["roughness"], "Emission Color": rgba(pose["emissive"]),
                  "Emission Strength": 1}
        for name, value in values.items():
            socket = shader.inputs[name]
            socket.default_value = value
            if len(layer["frames"]) > 1:
                socket.keyframe_insert(data_path="default_value", frame=frame)

camera = bpy.data.cameras.new("VD3D Camera")
scene.camera = add_object(camera.name, camera)
scene.camera.rotation_mode = 'QUATERNION'
camera.sensor_fit = 'HORIZONTAL'
previous = None
for frame, pose in enumerate(data["cameras"], 1):
    scene.camera.location = pose["position"]
    scene.camera.rotation_quaternion = (Vector(pose["target"]) - scene.camera.location).to_track_quat('-Z', 'Y')
    if previous and previous.dot(scene.camera.rotation_quaternion) < 0:
        scene.camera.rotation_quaternion.negate()
    previous = scene.camera.rotation_quaternion.copy()
    camera.type = 'ORTHO' if pose["projection"] == 'orthographic' else 'PERSP'
    fov = 35 if aspect >= 1 else min(95, 35 / aspect)
    camera.angle = 2 * atan(tan(radians(fov) / 2) * aspect / pose["zoom"])
    camera.ortho_scale = 5.7 * max(1, aspect) / pose["zoom"]
    if len(data["cameras"]) > 1:
        for prop in ("location", "rotation_quaternion"):
            scene.camera.keyframe_insert(data_path=prop, frame=frame)
        camera.keyframe_insert(data_path="lens", frame=frame)
        camera.keyframe_insert(data_path="ortho_scale", frame=frame)

for name, direction, power, size in (
    ("Key", data["key"], 800 * data["lights"]["strength"], 4),
    ("Fill", [-4, -4, 2], 350 * data["lights"]["fill"], 5),
    ("Rim", [1, 5, 3], 550, 3),
):
    light = bpy.data.lights.new(name, 'AREA')
    light.energy = power
    light.shape = 'DISK'
    light.size = size
    obj = add_object(name, light)
    obj.location = Vector(direction).normalized() * 6
    obj.rotation_euler = (-obj.location).to_track_quat('-Z', 'Y').to_euler()

scene.frame_set(1)
if __file__ and Path(__file__).is_file():
    source = Path(__file__)
    destination = source.with_suffix('.blend')
    i = 2
    while destination.exists():
        destination = source.with_name(f"{source.stem}-{i}.blend")
        i += 1
    bpy.ops.wm.save_as_mainfile(filepath=str(destination.resolve()))
`;function p(p,m){let h=p.timeline??o,g=h.duration*(h.loop===`ping-pong`?2:1),_=Math.ceil(g*h.fps),v=(h.tracks.length?Array.from({length:_+1},(e,t)=>r(Math.min(g,t/h.fps),h.duration,h.loop===`ping-pong`?`ping-pong`:`once`)):[0]).map(e=>s(p,e)),y=v[0].layers.filter(t=>e(p,t).visible).map((e,t)=>{let r=l(e),a=r.getAttribute(`normal`),o=r.getAttribute(`position`),s=[],d=[],f=new Map,p=Array.from({length:o.count},(e,t)=>{let n=[o.getX(t),-o.getZ(t),o.getY(t)],r=n.join(`,`);return f.has(r)||(f.set(r,s.length),s.push(n)),f.get(r)}),m=[];for(let e=0;e<(r.index?.count??p.length);e+=3){let t=[0,1,2].map(t=>r.index?.getX(e+t)??e+t),n=t.map(e=>p[e]);if(new Set(n).size===3){d.push(n);for(let e of t)m.push([a.getX(e),-a.getZ(e),a.getY(e)])}}r.dispose();let h=n[e.material];return{name:e.name,vertices:s,faces:d,normals:m,metalness:h.metalness,coat:h.clearcoat,glass:u(e.material),frames:v.map(n=>{let r=n.layers[t]?.id===e.id?n.layers[t]:n.layers.find(t=>t.id===e.id),a=new i().setFromEuler(new c(...r.rotation));return{position:[r.position[0],-r.position[2],r.position[1]],rotation:[a.w,a.x,-a.z,a.y],scale:[r.scale?.[0]??1,r.scale?.[2]??1,r.scale?.[1]??1],roughness:r.roughness??h.roughness,color:r.color,opacity:r.opacity,emissive:r.emissive??`#000000`}})}}),b={...a,...p.lighting},[x,S,C]=d(b),w={name:p.name,layers:y,fps:h.fps,count:_,aspect:m,lights:b,key:[x,-C,S],cameras:v.map(({camera:e})=>{let n=new t(...e.position),r=new t(...e.target);return{position:[n.x,-n.z,n.y],target:[r.x,-r.z,r.y],projection:e.projection,zoom:e.zoom}})},T=f.replace(`VD3D_PAYLOAD`,()=>JSON.stringify(JSON.stringify(w)).replace(/\u2028/g,`\\u2028`).replace(/\u2029/g,`\\u2029`)),E=URL.createObjectURL(new Blob([T],{type:`text/x-python`})),D=document.createElement(`a`);D.href=E,D.download=(p.name.replace(/[^\p{L}\p{N}_-]+/gu,`_`).slice(0,80)||`VD3D`)+`.py`,D.click(),window.setTimeout(()=>URL.revokeObjectURL(E),3e4)}export{p as downloadBlender};